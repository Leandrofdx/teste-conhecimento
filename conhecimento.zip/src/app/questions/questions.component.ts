import { Component, OnInit, Input } from '@angular/core';
import { QuestionsService } from './service/questions.service'
import {ActivatedRoute} from '@angular/router'
import 'rxjs/add/operator/do'
import {FormGroup, FormBuilder, Validators, FormControl, FormArray} from '@angular/forms'
import {Router} from '@angular/router'


@Component({
	selector: 'app-questions',
	templateUrl: './questions.component.html'
})

export class QuestionsComponent implements OnInit {
 
	public questions
	public objeto = []
	public options = []
	public play = false
	public visible = false
	public status = false
	public end = false
	public myOptions
	public cont:number = 1
	public optionsForm: FormGroup

	constructor(private questionsService: QuestionsService, private route: ActivatedRoute, private formBuilder: FormBuilder,  private router: Router) {}

	ngOnInit() { this.questionsService.questionById(this.route.snapshot.params['id']).subscribe(question => this.questions = question, request => console.log('Deu erro'), () => this.start()) 
    
	    this.optionsForm = this.formBuilder.group({
		  options: this.formBuilder.array([], Validators.required)
		});
	}

	onChange(option:string, isChecked: boolean) {

		var myOptions = <FormArray>this.optionsForm.controls.options;
		this.myOptions = myOptions

		if(isChecked) {
			myOptions.push(new FormControl(option));
		} else {
			let index = myOptions.controls.findIndex(x => x.value == option)
			myOptions.removeAt(index);
		}

	}

	start() {
		if(this.end) {
			this.router.navigate(['/win'])
		}

		var alternatives = this.questions.alternatives
		var options = []
		var nao = 'nao'
		var sim = 'sim'

		for (var i in alternatives) {

			if(alternatives[i].ativo === undefined && alternatives[i].ativo != nao)  {
				this.questions.alternatives.map(q => [q, q.ativo = nao, q.respondeu = nao ]);
				return false
			} 

			if(alternatives[i].ativo == nao && alternatives[i].respondeu == nao ) {
				this.objeto = []
				this.visible = false
				this.questions.alternatives[i].ativo = sim
				this.objeto.push(this.questions.alternatives[i])
				this.extract();
				return false
			}

			if(alternatives[i].ativo == sim && alternatives[i].respondeu == nao) {
				this.objeto = []
				this.questions.alternatives[i].ativo = nao
				this.questions.alternatives[i].respondeu = sim
				this.objeto.push(this.questions.alternatives[i])
				this.extract();
				this.result();
				return false
			}

		}
	}

	extract() {
		this.options = []
		for (var i in this.objeto) {
			console.log('mirra' + this.questions.name)
			for (var j in this.objeto[i].options) {
				for (var k in this.objeto[i].options[j]) {
					this.options.push(this.objeto[i].options[j][k])
				}

			}
		}
	}

	continuar() {
		this.play = true
		this.start()
	}

	result() {
		
		this.cont++
		const respostaCorreta = this.objeto[0].response
		const resposta = this.myOptions.value[0]

		if(resposta === respostaCorreta) {
			this.visible = true
			this.status = true
		} else {
			this.visible = true
			this.status = false
		}

		if(this.end == false && this.cont > this.questions.alternatives.length) {
			this.end = true
		}


	}






// var myObj, i, j, x = "";
// myObj = {
//     "name":"John",
//     "age":30,
//     "cars": [
//         { "name":"Ford", "models":[ "Fiesta", "Focus", "Mustang" ] },
//         { "name":"BMW", "models":[ "320", "X3", "X5" ] },
//         { "name":"Fiat", "models":[ "500", "Panda" ] }
//     ]
// }

// for (i in myObj.cars) {
//     x += "<h2>" + myObj.cars[i].name + "</h2>";
//     for (j in myObj.cars[i].models) {
//         x += myObj.cars[i].models[j] + "<br>";
//     }
// }





























}