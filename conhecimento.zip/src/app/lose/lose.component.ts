import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lose',
  templateUrl: './lose.component.html'
})
export class LoseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
