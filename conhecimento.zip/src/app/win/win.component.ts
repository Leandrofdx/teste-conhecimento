import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-win',
  templateUrl: './win.component.html'
})
export class WinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
